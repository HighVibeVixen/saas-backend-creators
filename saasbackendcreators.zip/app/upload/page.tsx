import { UploadManager } from "@/components/UploadManager"

export default function Upload() {
  return <UploadManager />
}
