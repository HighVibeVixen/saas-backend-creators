import { createClient } from "@supabase/supabase-js"

// Supabase configuration
const supabaseUrl = "https://dxksmffisebwrpjlcxff.supabase.co"
const supabaseKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR4a3NtZmZpc2Vid3JwamxjeGZmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA4NjMxMDIsImV4cCI6MjA2NjQzOTEwMn0.WCfWAtx9tPQH9N2lygdbaHUebIRilk5BbKR1dTY7wAk"

// Create Supabase client
export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
  },
  realtime: {
    params: {
      eventsPerSecond: 10,
    },
  },
})

// Database types
export interface Database {
  public: {
    Tables: {
      tenants: {
        Row: {
          id: string
          name: string
          slug: string
          description: string | null
          plan: string
          status: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          slug: string
          description?: string | null
          plan?: string
          status?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          slug?: string
          description?: string | null
          plan?: string
          status?: string
          created_at?: string
          updated_at?: string
        }
      }
      products: {
        Row: {
          id: string
          tenant_id: string
          title: string
          description: string | null
          price: number
          original_price: number | null
          featured: boolean
          image_url: string | null
          category: string | null
          status: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          tenant_id: string
          title: string
          description?: string | null
          price: number
          original_price?: number | null
          featured?: boolean
          image_url?: string | null
          category?: string | null
          status?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          tenant_id?: string
          title?: string
          description?: string | null
          price?: number
          original_price?: number | null
          featured?: boolean
          image_url?: string | null
          category?: string | null
          status?: string
          created_at?: string
          updated_at?: string
        }
      }
      members: {
        Row: {
          id: string
          tenant_id: string
          user_id: string
          email: string
          name: string | null
          membership_tier: string
          status: string
          joined_at: string
          expires_at: string | null
        }
        Insert: {
          id?: string
          tenant_id: string
          user_id: string
          email: string
          name?: string | null
          membership_tier?: string
          status?: string
          joined_at?: string
          expires_at?: string | null
        }
        Update: {
          id?: string
          tenant_id?: string
          user_id?: string
          email?: string
          name?: string | null
          membership_tier?: string
          status?: string
          joined_at?: string
          expires_at?: string | null
        }
      }
      uploads: {
        Row: {
          id: string
          tenant_id: string
          user_id: string
          filename: string
          file_path: string
          file_size: number | null
          mime_type: string | null
          status: string
          metadata: any | null
          created_at: string
        }
        Insert: {
          id?: string
          tenant_id: string
          user_id: string
          filename: string
          file_path: string
          file_size?: number | null
          mime_type?: string | null
          status?: string
          metadata?: any | null
          created_at?: string
        }
        Update: {
          id?: string
          tenant_id?: string
          user_id?: string
          filename?: string
          file_path?: string
          file_size?: number | null
          mime_type?: string | null
          status?: string
          metadata?: any | null
          created_at?: string
        }
      }
      analytics: {
        Row: {
          id: string
          tenant_id: string
          event_type: string
          event_data: any | null
          user_id: string | null
          session_id: string | null
          created_at: string
        }
        Insert: {
          id?: string
          tenant_id: string
          event_type: string
          event_data?: any | null
          user_id?: string | null
          session_id?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          tenant_id?: string
          event_type?: string
          event_data?: any | null
          user_id?: string | null
          session_id?: string | null
          created_at?: string
        }
      }
    }
  }
}

// Helper functions
export const getCurrentUser = async () => {
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()
  if (error) throw error
  return user
}

export const signOut = async () => {
  const { error } = await supabase.auth.signOut()
  if (error) throw error
}

export const signInWithEmail = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  })
  if (error) throw error
  return data
}

export const signUpWithEmail = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
  })
  if (error) throw error
  return data
}
