"use client"

import { useState, useEffect } from "react"
import { supabase, type Database } from "@/lib/supabase"
import { useToast } from "@/hooks/use-toast"

export type Product = Database["public"]["Tables"]["products"]["Row"]
export type Tenant = Database["public"]["Tables"]["tenants"]["Row"]
export type Member = Database["public"]["Tables"]["members"]["Row"]
export type Upload = Database["public"]["Tables"]["uploads"]["Row"]
export type Analytics = Database["public"]["Tables"]["analytics"]["Row"]

export const useSupabase = () => {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const { toast } = useToast()

  const handleError = (err: any, operation: string) => {
    const message = err?.message || `Failed to ${operation}`
    setError(message)
    toast({
      title: "Error",
      description: message,
      variant: "destructive",
    })
    console.error(`${operation} error:`, err)
  }

  // Products
  const fetchProducts = async (tenantId?: string): Promise<Product[]> => {
    setLoading(true)
    setError(null)
    try {
      let query = supabase.from("products").select("*").eq("status", "active").order("created_at", { ascending: false })

      if (tenantId) {
        query = query.eq("tenant_id", tenantId)
      }

      const { data, error } = await query
      if (error) throw error
      return data || []
    } catch (err) {
      handleError(err, "fetch products")
      return []
    } finally {
      setLoading(false)
    }
  }

  const createProduct = async (product: Omit<Product, "id" | "created_at" | "updated_at">): Promise<Product | null> => {
    setLoading(true)
    setError(null)
    try {
      const { data, error } = await supabase.from("products").insert([product]).select().single()

      if (error) throw error

      toast({
        title: "Success",
        description: "Product created successfully",
      })

      return data
    } catch (err) {
      handleError(err, "create product")
      return null
    } finally {
      setLoading(false)
    }
  }

  const updateProduct = async (id: string, updates: Partial<Product>): Promise<Product | null> => {
    setLoading(true)
    setError(null)
    try {
      const { data, error } = await supabase
        .from("products")
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq("id", id)
        .select()
        .single()

      if (error) throw error

      toast({
        title: "Success",
        description: "Product updated successfully",
      })

      return data
    } catch (err) {
      handleError(err, "update product")
      return null
    } finally {
      setLoading(false)
    }
  }

  const deleteProduct = async (id: string): Promise<boolean> => {
    setLoading(true)
    setError(null)
    try {
      const { error } = await supabase.from("products").delete().eq("id", id)

      if (error) throw error

      toast({
        title: "Success",
        description: "Product deleted successfully",
      })

      return true
    } catch (err) {
      handleError(err, "delete product")
      return false
    } finally {
      setLoading(false)
    }
  }

  // Tenants
  const fetchTenants = async (): Promise<Tenant[]> => {
    setLoading(true)
    setError(null)
    try {
      const { data, error } = await supabase
        .from("tenants")
        .select("*")
        .eq("status", "active")
        .order("created_at", { ascending: false })

      if (error) throw error
      return data || []
    } catch (err) {
      handleError(err, "fetch tenants")
      return []
    } finally {
      setLoading(false)
    }
  }

  // Members
  const fetchMembers = async (tenantId: string): Promise<Member[]> => {
    setLoading(true)
    setError(null)
    try {
      const { data, error } = await supabase
        .from("members")
        .select("*")
        .eq("tenant_id", tenantId)
        .eq("status", "active")
        .order("joined_at", { ascending: false })

      if (error) throw error
      return data || []
    } catch (err) {
      handleError(err, "fetch members")
      return []
    } finally {
      setLoading(false)
    }
  }

  // Analytics
  const fetchAnalytics = async (tenantId: string, eventType?: string): Promise<Analytics[]> => {
    setLoading(true)
    setError(null)
    try {
      let query = supabase
        .from("analytics")
        .select("*")
        .eq("tenant_id", tenantId)
        .order("created_at", { ascending: false })

      if (eventType) {
        query = query.eq("event_type", eventType)
      }

      const { data, error } = await query
      if (error) throw error
      return data || []
    } catch (err) {
      handleError(err, "fetch analytics")
      return []
    } finally {
      setLoading(false)
    }
  }

  const trackEvent = async (tenantId: string, eventType: string, eventData: any): Promise<boolean> => {
    try {
      const { error } = await supabase.from("analytics").insert([
        {
          tenant_id: tenantId,
          event_type: eventType,
          event_data: eventData,
          created_at: new Date().toISOString(),
        },
      ])

      if (error) throw error
      return true
    } catch (err) {
      console.error("Track event error:", err)
      return false
    }
  }

  // File uploads
  const uploadFile = async (file: File, bucket = "uploads"): Promise<string | null> => {
    setLoading(true)
    setError(null)
    try {
      const fileExt = file.name.split(".").pop()
      const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`
      const filePath = `${bucket}/${fileName}`

      const { error: uploadError } = await supabase.storage.from(bucket).upload(filePath, file)

      if (uploadError) throw uploadError

      const { data } = supabase.storage.from(bucket).getPublicUrl(filePath)

      toast({
        title: "Success",
        description: "File uploaded successfully",
      })

      return data.publicUrl
    } catch (err) {
      handleError(err, "upload file")
      return null
    } finally {
      setLoading(false)
    }
  }

  return {
    loading,
    error,
    // Products
    fetchProducts,
    createProduct,
    updateProduct,
    deleteProduct,
    // Tenants
    fetchTenants,
    // Members
    fetchMembers,
    // Analytics
    fetchAnalytics,
    trackEvent,
    // Files
    uploadFile,
  }
}

// Auth hook
export const useAuth = () => {
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null)
      setLoading(false)
    })

    // Listen for auth changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      setUser(session?.user ?? null)
      setLoading(false)

      if (event === "SIGNED_IN") {
        toast({
          title: "Welcome!",
          description: "You have been signed in successfully",
        })
      } else if (event === "SIGNED_OUT") {
        toast({
          title: "Goodbye!",
          description: "You have been signed out",
        })
      }
    })

    return () => subscription.unsubscribe()
  }, [toast])

  return {
    user,
    loading,
    signOut: () => supabase.auth.signOut(),
  }
}
