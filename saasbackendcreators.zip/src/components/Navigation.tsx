"use client"

import type React from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  LayoutDashboard,
  ShoppingBag,
  Users,
  Video,
  MessageSquare,
  BarChart3,
  Settings,
  Bell,
  Search,
  Menu,
  X,
  Upload,
  Sparkles,
} from "lucide-react"
import { useAppContext } from "@/contexts/AppContext"
import { Link, useLocation } from "react-router-dom"

const Navigation: React.FC = () => {
  const { sidebarOpen, toggleSidebar } = useAppContext()
  const location = useLocation()

  const navItems = [
    { icon: LayoutDashboard, label: "Dashboard", path: "/", badge: null, gradient: "from-blue-500 to-indigo-600" },
    { icon: Upload, label: "Upload Project", path: "/upload", badge: "New", gradient: "from-emerald-500 to-teal-600" },
    { icon: ShoppingBag, label: "Products", path: "/products", badge: "12", gradient: "from-purple-500 to-pink-600" },
    { icon: Users, label: "Members", path: "/members", badge: "1.2k", gradient: "from-orange-500 to-red-500" },
    { icon: Video, label: "Live Streams", path: "/streams", badge: null, gradient: "from-red-500 to-pink-600" },
    { icon: MessageSquare, label: "Reviews", path: "/reviews", badge: "5", gradient: "from-green-500 to-emerald-600" },
    { icon: BarChart3, label: "Analytics", path: "/analytics", badge: null, gradient: "from-cyan-500 to-blue-600" },
    { icon: Settings, label: "Settings", path: "/settings", badge: null, gradient: "from-gray-500 to-gray-700" },
  ]

  return (
    <>
      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-200/50 px-4 py-3 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={toggleSidebar} className="hover:bg-gray-100">
              {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center">
                <Sparkles className="h-4 w-4 text-white" />
              </div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                Creator Universe
              </h1>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="relative hover:bg-gray-100">
              <Bell className="h-5 w-5" />
              <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 text-xs bg-red-500 border-2 border-white">3</Badge>
            </Button>
            <Avatar className="h-8 w-8 ring-2 ring-indigo-100">
              <AvatarImage src="/placeholder.svg" />
              <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white text-sm font-semibold">
                JD
              </AvatarFallback>
            </Avatar>
          </div>
        </div>
      </div>

      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-40 w-72 bg-white/95 backdrop-blur-md border-r border-gray-200/50 shadow-xl transform transition-transform duration-300 ease-in-out ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        } lg:translate-x-0`}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="hidden lg:flex items-center gap-3 p-6 border-b border-gray-200/50">
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg">
              <Sparkles className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                Creator Universe
              </h1>
              <p className="text-xs text-gray-500 font-medium">Your creative sanctuary</p>
            </div>
          </div>

          {/* Search */}
          <div className="p-4 border-b border-gray-200/50">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search anything..."
                className="w-full pl-10 pr-4 py-3 bg-gray-50/80 border border-gray-200/50 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 transition-all"
              />
            </div>
          </div>

          {/* Navigation Items */}
          <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
            {navItems.map((item, index) => {
              const Icon = item.icon
              const isActive = location.pathname === item.path
              return (
                <Link key={index} to={item.path}>
                  <Button
                    variant="ghost"
                    className={`w-full justify-start gap-4 h-14 px-4 rounded-xl transition-all duration-300 group ${
                      isActive
                        ? "bg-gradient-to-r from-indigo-50 to-purple-50 text-indigo-700 shadow-md border border-indigo-100"
                        : "hover:bg-gray-50 text-gray-700 hover:text-gray-900"
                    }`}
                  >
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300 ${
                        isActive
                          ? `bg-gradient-to-br ${item.gradient} shadow-lg`
                          : "bg-gray-100 group-hover:bg-gray-200"
                      }`}
                    >
                      <Icon className={`h-5 w-5 ${isActive ? "text-white" : "text-gray-600"}`} />
                    </div>
                    <span className="flex-1 text-left font-medium">{item.label}</span>
                    {item.badge && (
                      <Badge
                        variant="secondary"
                        className={`text-xs font-semibold ${
                          isActive
                            ? "bg-white/80 text-indigo-700 border border-indigo-200"
                            : item.badge === "New"
                              ? "bg-emerald-100 text-emerald-700 border border-emerald-200"
                              : "bg-gray-100 text-gray-600 border border-gray-200"
                        }`}
                      >
                        {item.badge}
                      </Badge>
                    )}
                  </Button>
                </Link>
              )
            })}
          </nav>

          {/* User Profile */}
          <div className="p-4 border-t border-gray-200/50">
            <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-gray-50 to-indigo-50/50 rounded-xl border border-gray-200/50">
              <Avatar className="h-12 w-12 ring-2 ring-indigo-100">
                <AvatarImage src="/placeholder.svg" />
                <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-semibold">
                  JD
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-gray-900 truncate">John Doe</p>
                <p className="text-sm text-gray-500 truncate">john@example.com</p>
                <div className="flex items-center gap-1 mt-1">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span className="text-xs text-green-600 font-medium">Pro Creator</span>
                </div>
              </div>
              <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-white/80">
                <Settings className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-30 bg-black/50 backdrop-blur-sm" onClick={toggleSidebar} />
      )}
    </>
  )
}

export default Navigation
