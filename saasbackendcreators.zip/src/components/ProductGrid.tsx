"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Star, ShoppingCart, Plus, Sparkles, Heart, Share2 } from "lucide-react"
import { useSupabase, type Product } from "@/hooks/useSupabase"
import { useToast } from "@/hooks/use-toast"

const ProductGrid: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([])
  const { fetchProducts, loading, error, trackEvent } = useSupabase()
  const { toast } = useToast()

  useEffect(() => {
    loadProducts()
  }, [])

  const loadProducts = async () => {
    const data = await fetchProducts()
    setProducts(data)
  }

  const handlePurchase = async (product: Product) => {
    // Track purchase intent
    await trackEvent(product.tenant_id, "purchase_intent", {
      product_id: product.id,
      product_title: product.title,
      price: product.price,
    })

    toast({
      title: "🛒 Added to Cart",
      description: `${product.title} has been added to your cart`,
    })
  }

  const handleWishlist = async (product: Product) => {
    await trackEvent(product.tenant_id, "wishlist_add", {
      product_id: product.id,
      product_title: product.title,
    })

    toast({
      title: "💖 Added to Wishlist",
      description: `${product.title} saved for later`,
    })
  }

  const handleShare = async (product: Product) => {
    await trackEvent(product.tenant_id, "product_share", {
      product_id: product.id,
      product_title: product.title,
    })

    if (navigator.share) {
      navigator.share({
        title: product.title,
        text: product.description || "",
        url: window.location.href,
      })
    } else {
      navigator.clipboard.writeText(window.location.href)
      toast({
        title: "🔗 Link Copied",
        description: "Product link copied to clipboard",
      })
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-purple-50/30 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="animate-pulse border-0 shadow-lg">
                <div className="h-48 bg-gradient-to-r from-gray-200 to-gray-300 rounded-t-lg"></div>
                <CardContent className="p-6 space-y-3">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-full"></div>
                  <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                  <div className="h-8 bg-gray-200 rounded"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-purple-50/30">
      <div className="max-w-7xl mx-auto p-6 space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-100 to-pink-100 rounded-full px-6 py-3">
            <Sparkles className="h-5 w-5 text-purple-600" />
            <span className="text-purple-700 font-semibold">Premium Marketplace</span>
          </div>

          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-gray-900 via-purple-900 to-pink-900 bg-clip-text text-transparent">
            Creator Products
          </h2>

          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Discover premium courses, templates, and resources crafted by top creators
          </p>

          <div className="flex items-center justify-center gap-6 text-sm text-gray-500">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span>{products.length} Products Available</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span>Live Database Connected</span>
            </div>
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <Card
              key={product.id}
              className="group overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 bg-white/80 backdrop-blur-sm"
            >
              <div className="relative overflow-hidden">
                <img
                  src={product.image_url || "/placeholder.svg?height=200&width=300&text=Product+Image"}
                  alt={product.title}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                />

                {/* Overlay with actions */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-4 left-4 right-4 flex gap-2">
                    <Button
                      size="sm"
                      variant="secondary"
                      className="flex-1 bg-white/90 hover:bg-white text-gray-900"
                      onClick={() => handlePurchase(product)}
                    >
                      <ShoppingCart className="h-4 w-4 mr-2" />
                      Add to Cart
                    </Button>
                    <Button
                      size="sm"
                      variant="secondary"
                      className="bg-white/90 hover:bg-white text-gray-900"
                      onClick={() => handleWishlist(product)}
                    >
                      <Heart className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="secondary"
                      className="bg-white/90 hover:bg-white text-gray-900"
                      onClick={() => handleShare(product)}
                    >
                      <Share2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {/* Badges */}
                <div className="absolute top-3 left-3 flex flex-col gap-2">
                  {product.featured && (
                    <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white border-0 shadow-lg">
                      ⭐ Featured
                    </Badge>
                  )}
                  {product.category && (
                    <Badge variant="secondary" className="bg-white/90 text-gray-700 capitalize">
                      {product.category}
                    </Badge>
                  )}
                </div>

                {/* Discount badge */}
                {product.original_price && product.original_price > product.price && (
                  <Badge className="absolute top-3 right-3 bg-red-500 text-white">
                    {Math.round(((product.original_price - product.price) / product.original_price) * 100)}% OFF
                  </Badge>
                )}
              </div>

              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-bold text-gray-900 group-hover:text-purple-700 transition-colors line-clamp-2">
                  {product.title}
                </CardTitle>
                <CardDescription className="text-gray-600 line-clamp-2 leading-relaxed">
                  {product.description}
                </CardDescription>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                      ${product.price}
                    </span>
                    {product.original_price && (
                      <span className="text-sm text-gray-500 line-through">${product.original_price}</span>
                    )}
                  </div>
                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                    <span className="text-sm text-gray-600 ml-1">(4.8)</span>
                  </div>
                </div>

                <Button
                  className="w-full gap-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
                  onClick={() => handlePurchase(product)}
                >
                  <ShoppingCart className="h-4 w-4" />
                  Purchase Now
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {products.length === 0 && !loading && (
          <div className="text-center py-16">
            <div className="w-24 h-24 bg-gradient-to-br from-purple-100 to-pink-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <ShoppingCart className="h-12 w-12 text-purple-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">No products found</h3>
            <p className="text-gray-600 mb-6">Start building your creator marketplace</p>
            <Button className="gap-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
              <Plus className="h-4 w-4" />
              Create Your First Product
            </Button>
          </div>
        )}

        {/* Error State */}
        {error && (
          <div className="text-center py-16">
            <div className="w-24 h-24 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <span className="text-2xl">⚠️</span>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Connection Error</h3>
            <p className="text-gray-600 mb-6">{error}</p>
            <Button onClick={loadProducts} variant="outline">
              Try Again
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}

export default ProductGrid
