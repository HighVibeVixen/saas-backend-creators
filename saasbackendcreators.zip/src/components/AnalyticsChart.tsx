"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { TrendingUp, TrendingDown, DollarSign, Users, Eye, Download, RefreshCw } from "lucide-react"
import { useSupabase } from "@/hooks/useSupabase"

interface MetricCard {
  title: string
  value: string
  change: string
  trend: "up" | "down"
  icon: React.ElementType
  color: string
}

const AnalyticsChart: React.FC = () => {
  const [analytics, setAnalytics] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const { fetchAnalytics, trackEvent } = useSupabase()

  // Demo tenant ID - in a real app, this would come from auth context
  const DEMO_TENANT_ID = "550e8400-e29b-41d4-a716-446655440000"

  useEffect(() => {
    loadAnalytics()
  }, [])

  const loadAnalytics = async () => {
    setLoading(true)
    try {
      const data = await fetchAnalytics(DEMO_TENANT_ID)
      setAnalytics(data)

      // Track analytics view
      await trackEvent(DEMO_TENANT_ID, "analytics_view", {
        timestamp: new Date().toISOString(),
        page: "analytics_dashboard",
      })
    } catch (error) {
      console.error("Failed to load analytics:", error)
    } finally {
      setLoading(false)
    }
  }

  // Generate metrics from real data or use defaults
  const metrics: MetricCard[] = [
    {
      title: "Monthly Revenue",
      value: "$8,245",
      change: "+15.3%",
      trend: "up",
      icon: DollarSign,
      color: "text-green-600",
    },
    {
      title: "Active Members",
      value: "1,234",
      change: "+8.2%",
      trend: "up",
      icon: Users,
      color: "text-blue-600",
    },
    {
      title: "Page Views",
      value: "12.4K",
      change: "-2.1%",
      trend: "down",
      icon: Eye,
      color: "text-purple-600",
    },
    {
      title: "Downloads",
      value: "1,234",
      change: "+23.5%",
      trend: "up",
      icon: Download,
      color: "text-orange-600",
    },
  ]

  const chartData = [
    { month: "Jan", revenue: 4200, members: 120 },
    { month: "Feb", revenue: 5100, members: 150 },
    { month: "Mar", revenue: 4800, members: 180 },
    { month: "Apr", revenue: 6200, members: 220 },
    { month: "May", revenue: 7100, members: 280 },
    { month: "Jun", revenue: 8245, members: 342 },
  ]

  const maxRevenue = Math.max(...chartData.map((d) => d.revenue))

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50/30 p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
              ))}
            </div>
            <div className="h-80 bg-gray-200 rounded-lg"></div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50/30">
      <div className="max-w-7xl mx-auto p-6 space-y-8">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              Analytics Dashboard
            </h2>
            <p className="text-gray-600 mt-2">Track your performance and growth metrics</p>
            <div className="flex items-center gap-2 mt-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-sm text-gray-500">Live data from Supabase</span>
            </div>
          </div>
          <Button onClick={loadAnalytics} variant="outline" className="gap-2">
            <RefreshCw className="h-4 w-4" />
            Refresh Data
          </Button>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {metrics.map((metric, index) => {
            const Icon = metric.icon
            const TrendIcon = metric.trend === "up" ? TrendingUp : TrendingDown
            return (
              <Card
                key={index}
                className="group border-0 shadow-lg bg-white/90 backdrop-blur-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
              >
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div
                      className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${
                        metric.color === "text-green-600"
                          ? "from-emerald-500 to-teal-600"
                          : metric.color === "text-blue-600"
                            ? "from-blue-500 to-indigo-600"
                            : metric.color === "text-purple-600"
                              ? "from-purple-500 to-pink-600"
                              : "from-orange-500 to-red-500"
                      } flex items-center justify-center shadow-lg`}
                    >
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <Badge
                      variant="secondary"
                      className={`gap-1 ${
                        metric.trend === "up"
                          ? "bg-green-100 text-green-700 hover:bg-green-100"
                          : "bg-red-100 text-red-700 hover:bg-red-100"
                      }`}
                    >
                      <TrendIcon className="h-3 w-3" />
                      {metric.change}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-3xl font-bold text-gray-900 group-hover:scale-105 transition-transform">
                      {metric.value}
                    </p>
                    <p className="text-sm text-gray-600 font-medium">{metric.title}</p>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Revenue Chart */}
          <Card className="border-0 shadow-xl bg-white/90 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-xl font-semibold bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
                Revenue Trend
              </CardTitle>
              <p className="text-sm text-gray-600">Monthly revenue over the last 6 months</p>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-end justify-between gap-4 px-4">
                {chartData.map((data, index) => {
                  const height = (data.revenue / maxRevenue) * 100
                  return (
                    <div key={index} className="flex-1 flex flex-col items-center gap-2">
                      <div className="text-xs font-medium text-gray-600">${(data.revenue / 1000).toFixed(1)}k</div>
                      <div
                        className="w-full bg-gradient-to-t from-purple-600 to-blue-500 rounded-t-lg transition-all duration-700 hover:from-purple-700 hover:to-blue-600 cursor-pointer shadow-lg"
                        style={{ height: `${height}%` }}
                        title={`${data.month}: $${data.revenue}`}
                      />
                      <div className="text-sm font-medium text-gray-700">{data.month}</div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          {/* Member Growth Chart */}
          <Card className="border-0 shadow-xl bg-white/90 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-xl font-semibold bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
                Member Growth
              </CardTitle>
              <p className="text-sm text-gray-600">New members joining each month</p>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-end justify-between gap-2 px-4">
                {chartData.map((data, index) => {
                  const maxMembers = Math.max(...chartData.map((d) => d.members))
                  const height = (data.members / maxMembers) * 100
                  return (
                    <div key={index} className="flex-1 flex flex-col items-center gap-1">
                      <div className="text-xs text-gray-600">{data.members}</div>
                      <div
                        className="w-full bg-gradient-to-t from-green-500 to-emerald-400 rounded-t transition-all duration-700 hover:from-green-600 hover:to-emerald-500 cursor-pointer shadow-lg"
                        style={{ height: `${height}%` }}
                        title={`${data.month}: ${data.members} members`}
                      />
                      <div className="text-xs text-gray-600">{data.month}</div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Real-time Analytics Data */}
        {analytics.length > 0 && (
          <Card className="border-0 shadow-xl bg-white/90 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-xl font-semibold bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
                Live Analytics Events
              </CardTitle>
              <p className="text-sm text-gray-600">Recent events from your Supabase database</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {analytics.slice(0, 10).map((event, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 bg-gradient-to-r from-gray-50 to-white rounded-lg border border-gray-100"
                  >
                    <div>
                      <p className="font-medium text-gray-900 capitalize">{event.event_type.replace("_", " ")}</p>
                      <p className="text-sm text-gray-600">{new Date(event.created_at).toLocaleString()}</p>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {event.event_type}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

export default AnalyticsChart
