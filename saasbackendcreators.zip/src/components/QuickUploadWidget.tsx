import type React from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Upload, FolderOpen, Sparkles, Zap, Shield } from "lucide-react"
import { Link } from "react-router-dom"

export const QuickUploadWidget: React.FC = () => {
  return (
    <Card className="relative overflow-hidden border-0 shadow-xl bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-700">
      {/* Background decorative elements */}
      <div className="absolute inset-0">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl transform translate-x-32 -translate-y-32"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-yellow-400/20 rounded-full blur-2xl transform -translate-x-24 translate-y-24"></div>
      </div>

      <CardContent className="relative p-8">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
          <div className="flex-1 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
                <Upload className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-white">Project Integration Hub</h3>
                <p className="text-blue-100">Seamlessly integrate your creative projects</p>
              </div>
            </div>

            <p className="text-lg text-white/90 max-w-2xl leading-relaxed">
              Transform your project folders into powerful creator experiences. Our AI-powered integration analyzes your
              content and creates beautiful, interactive showcases automatically.
            </p>

            <div className="flex flex-wrap items-center gap-6 text-sm text-white/80">
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-yellow-300" />
                <span>AI-Powered Analysis</span>
              </div>
              <div className="flex items-center gap-2">
                <Zap className="h-4 w-4 text-yellow-300" />
                <span>Instant Integration</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-yellow-300" />
                <span>Secure Processing</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-4">
            <Link to="/upload">
              <Button className="bg-white text-indigo-600 hover:bg-white/90 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105 px-8 py-3 text-lg font-semibold">
                <FolderOpen className="h-5 w-5 mr-3" />
                Upload Project
              </Button>
            </Link>
            <Button variant="outline" className="border-white/30 text-white hover:bg-white/10 backdrop-blur-sm">
              Learn More
            </Button>
          </div>
        </div>

        {/* Progress indicators */}
        <div className="mt-8 flex items-center justify-between text-xs text-white/70">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-400"></div>
              <span>All Systems Operational</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-blue-400"></div>
              <span>Processing Speed: 2.3s avg</span>
            </div>
          </div>
          <div className="text-white/60">Trusted by 10,000+ creators worldwide</div>
        </div>
      </CardContent>
    </Card>
  )
}
