import type React from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { QuickUploadWidget } from "@/components/QuickUploadWidget"
import { Users, DollarSign, ShoppingBag, TrendingUp, Plus, Settings, Sparkles, Crown, Zap } from "lucide-react"

const CreatorDashboard: React.FC = () => {
  const stats = [
    {
      title: "Total Revenue",
      value: "$12,345",
      icon: DollarSign,
      change: "+12%",
      gradient: "from-emerald-500 to-teal-600",
      bgGradient: "from-emerald-50 to-teal-50",
    },
    {
      title: "Active Members",
      value: "1,234",
      icon: Users,
      change: "+5%",
      gradient: "from-blue-500 to-indigo-600",
      bgGradient: "from-blue-50 to-indigo-50",
    },
    {
      title: "Products Sold",
      value: "89",
      icon: ShoppingBag,
      change: "+23%",
      gradient: "from-purple-500 to-pink-600",
      bgGradient: "from-purple-50 to-pink-50",
    },
    {
      title: "Growth Rate",
      value: "15%",
      icon: TrendingUp,
      change: "+2%",
      gradient: "from-orange-500 to-red-500",
      bgGradient: "from-orange-50 to-red-50",
    },
  ]

  const quickActions = [
    {
      title: "Create Premium Course",
      description: "Launch your next masterpiece",
      icon: Crown,
      gradient: "from-amber-500 to-orange-600",
      bgGradient: "from-amber-50 to-orange-50",
    },
    {
      title: "Design Workshop",
      description: "Host an exclusive session",
      icon: Sparkles,
      gradient: "from-violet-500 to-purple-600",
      bgGradient: "from-violet-50 to-purple-50",
    },
    {
      title: "Analytics Deep Dive",
      description: "Understand your audience",
      icon: Zap,
      gradient: "from-cyan-500 to-blue-600",
      bgGradient: "from-cyan-50 to-blue-50",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50/30">
      <div className="max-w-7xl mx-auto space-y-8 p-6">
        {/* Hero Header */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 p-8 text-white">
          <div className="absolute inset-0 bg-black/10"></div>
          <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm rounded-full px-4 py-2">
                <Sparkles className="h-4 w-4" />
                <span className="text-sm font-medium">Creator Universe</span>
              </div>
              <h1 className="text-4xl md:text-5xl font-bold leading-tight">
                Welcome back,
                <br />
                <span className="bg-gradient-to-r from-yellow-300 to-orange-300 bg-clip-text text-transparent">
                  Creative Genius
                </span>
              </h1>
              <p className="text-lg text-white/90 max-w-2xl">
                Your creative empire awaits. Build, inspire, and monetize your passion with our premium creator tools.
              </p>
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                className="gap-2 bg-white/10 border-white/20 text-white hover:bg-white/20 backdrop-blur-sm"
              >
                <Settings className="h-4 w-4" />
                Settings
              </Button>
              <Button className="gap-2 bg-white text-indigo-600 hover:bg-white/90 shadow-lg">
                <Plus className="h-4 w-4" />
                New Creation
              </Button>
            </div>
          </div>
          {/* Decorative elements */}
          <div className="absolute -top-4 -right-4 w-24 h-24 bg-white/10 rounded-full blur-xl"></div>
          <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-yellow-400/20 rounded-full blur-2xl"></div>
        </div>

        {/* Upload Widget */}
        <QuickUploadWidget />

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => {
            const Icon = stat.icon
            return (
              <Card
                key={index}
                className="group relative overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-1"
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${stat.bgGradient} opacity-50`}></div>
                <CardContent className="relative p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div
                      className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${stat.gradient} flex items-center justify-center shadow-lg`}
                    >
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <Badge variant="secondary" className="bg-green-100 text-green-700 border-green-200 shadow-sm">
                      {stat.change}
                    </Badge>
                  </div>
                  <div className="space-y-1">
                    <p className="text-3xl font-bold text-gray-900 group-hover:scale-105 transition-transform">
                      {stat.value}
                    </p>
                    <p className="text-sm text-gray-600 font-medium">{stat.title}</p>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Revenue Chart */}
          <Card className="lg:col-span-2 border-0 shadow-xl bg-white/80 backdrop-blur-sm">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
                    Revenue Analytics
                  </CardTitle>
                  <CardDescription className="text-gray-600 mt-1">
                    Your earnings trajectory over the last 6 months
                  </CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-gradient-to-r from-indigo-500 to-purple-600"></div>
                  <span className="text-sm text-gray-600">Revenue</span>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-end justify-between gap-4 px-4">
                {[4200, 5100, 4800, 6200, 7100, 8245].map((value, index) => {
                  const height = (value / 8245) * 100
                  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"]
                  return (
                    <div key={index} className="flex-1 flex flex-col items-center gap-3">
                      <div className="text-xs font-semibold text-gray-700">${(value / 1000).toFixed(1)}k</div>
                      <div
                        className="w-full bg-gradient-to-t from-indigo-600 via-purple-500 to-pink-500 rounded-t-xl transition-all duration-700 hover:from-indigo-700 hover:via-purple-600 hover:to-pink-600 cursor-pointer shadow-lg"
                        style={{ height: `${height}%` }}
                        title={`${months[index]}: $${value}`}
                      />
                      <div className="text-sm font-medium text-gray-700">{months[index]}</div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="border-0 shadow-xl bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
                Quick Actions
              </CardTitle>
              <CardDescription>Launch your next big idea</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {quickActions.map((action, index) => {
                const Icon = action.icon
                return (
                  <Button
                    key={index}
                    variant="outline"
                    className="w-full h-auto p-4 border-0 shadow-md hover:shadow-lg transition-all duration-300 group"
                  >
                    <div
                      className={`absolute inset-0 bg-gradient-to-br ${action.bgGradient} opacity-50 rounded-lg`}
                    ></div>
                    <div className="relative flex items-center gap-4 w-full">
                      <div
                        className={`w-10 h-10 rounded-xl bg-gradient-to-br ${action.gradient} flex items-center justify-center shadow-md group-hover:scale-110 transition-transform`}
                      >
                        <Icon className="h-5 w-5 text-white" />
                      </div>
                      <div className="text-left flex-1">
                        <p className="font-semibold text-gray-900">{action.title}</p>
                        <p className="text-sm text-gray-600">{action.description}</p>
                      </div>
                    </div>
                  </Button>
                )
              })}
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <Card className="border-0 shadow-xl bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
                  Recent Activity
                </CardTitle>
                <CardDescription className="mt-1">Latest updates from your creator space</CardDescription>
              </div>
              <Button variant="outline" className="gap-2">
                View All
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                {
                  title: "New premium member joined your community",
                  time: "2 hours ago",
                  type: "member",
                  gradient: "from-blue-500 to-indigo-600",
                },
                {
                  title: 'Course "Advanced Design Patterns" reached 100 sales',
                  time: "5 hours ago",
                  type: "milestone",
                  gradient: "from-emerald-500 to-teal-600",
                },
                {
                  title: "Live stream session completed with 234 viewers",
                  time: "1 day ago",
                  type: "stream",
                  gradient: "from-purple-500 to-pink-600",
                },
              ].map((item, index) => (
                <div
                  key={index}
                  className="flex items-center gap-4 p-4 bg-gradient-to-r from-gray-50 to-white rounded-xl border border-gray-100 hover:shadow-md transition-all duration-300"
                >
                  <div className={`w-3 h-3 rounded-full bg-gradient-to-r ${item.gradient} shadow-sm`}></div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{item.title}</p>
                    <p className="text-sm text-gray-600">{item.time}</p>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {item.type}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default CreatorDashboard
