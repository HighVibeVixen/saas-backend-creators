import type React from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Check, Star, Crown, Zap, Sparkles } from "lucide-react"

interface MembershipTier {
  id: string
  name: string
  price: number
  period: string
  description: string
  features: string[]
  popular: boolean
  icon: React.ElementType
  gradient: string
  bgGradient: string
  textColor: string
}

const MembershipTiers: React.FC = () => {
  const tiers: MembershipTier[] = [
    {
      id: "free",
      name: "Creator",
      price: 0,
      period: "forever",
      description: "Perfect for getting started on your creative journey",
      features: [
        "Access to community forums",
        "Basic project templates",
        "Standard support",
        "Monthly creator newsletter",
        "Basic analytics dashboard",
      ],
      popular: false,
      icon: Star,
      gradient: "from-gray-600 to-gray-800",
      bgGradient: "from-gray-50 to-gray-100",
      textColor: "text-gray-700",
    },
    {
      id: "pro",
      name: "Pro Creator",
      price: 29,
      period: "month",
      description: "For serious creators ready to monetize their passion",
      features: [
        "Everything in Creator plan",
        "Premium content library access",
        "Live masterclass sessions",
        "Priority community support",
        "Advanced analytics & insights",
        "Custom branding options",
        "Direct creator messaging",
      ],
      popular: true,
      icon: Zap,
      gradient: "from-indigo-600 to-purple-700",
      bgGradient: "from-indigo-50 to-purple-50",
      textColor: "text-indigo-700",
    },
    {
      id: "elite",
      name: "Elite Creator",
      price: 99,
      period: "month",
      description: "Ultimate creator experience with exclusive perks",
      features: [
        "Everything in Pro Creator plan",
        "One-on-one mentorship sessions",
        "Exclusive VIP community access",
        "Early access to new features",
        "Custom project development",
        "Revenue optimization consulting",
        "White-label solutions",
        "Dedicated account manager",
      ],
      popular: false,
      icon: Crown,
      gradient: "from-amber-500 to-orange-600",
      bgGradient: "from-amber-50 to-orange-50",
      textColor: "text-amber-700",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-purple-50/30 py-16">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header Section */}
        <div className="text-center space-y-6 mb-16">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-indigo-100 to-purple-100 rounded-full px-6 py-3">
            <Sparkles className="h-5 w-5 text-indigo-600" />
            <span className="text-indigo-700 font-semibold">Membership Plans</span>
          </div>

          <h2 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-gray-900 via-indigo-900 to-purple-900 bg-clip-text text-transparent leading-tight">
            Choose Your
            <br />
            Creative Journey
          </h2>

          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Join thousands of creators who have transformed their passion into profit. Each plan is designed to
            accelerate your creative success with premium tools, exclusive content, and a supportive community.
          </p>

          <div className="flex items-center justify-center gap-8 text-sm text-gray-500">
            <div className="flex items-center gap-2">
              <Check className="h-4 w-4 text-green-500" />
              <span>30-day money-back guarantee</span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="h-4 w-4 text-green-500" />
              <span>Cancel anytime</span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="h-4 w-4 text-green-500" />
              <span>Secure payment</span>
            </div>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {tiers.map((tier) => {
            const Icon = tier.icon
            return (
              <Card
                key={tier.id}
                className={`relative overflow-hidden border-2 transition-all duration-500 hover:shadow-2xl hover:-translate-y-2 ${
                  tier.popular
                    ? "border-indigo-200 shadow-2xl scale-105 bg-white"
                    : "border-gray-200 bg-white/80 backdrop-blur-sm hover:border-indigo-200"
                }`}
              >
                {/* Popular badge */}
                {tier.popular && (
                  <div className="absolute top-0 left-0 right-0">
                    <div
                      className={`bg-gradient-to-r ${tier.gradient} text-white text-center py-3 text-sm font-bold tracking-wide`}
                    >
                      ⭐ MOST POPULAR CHOICE
                    </div>
                  </div>
                )}

                {/* Background gradient */}
                <div className={`absolute inset-0 bg-gradient-to-br ${tier.bgGradient} opacity-30`}></div>

                <CardHeader className={`text-center relative z-10 ${tier.popular ? "pt-16" : "pt-8"}`}>
                  <div
                    className={`w-20 h-20 mx-auto rounded-3xl bg-gradient-to-br ${tier.gradient} flex items-center justify-center mb-6 shadow-xl`}
                  >
                    <Icon className="h-10 w-10 text-white" />
                  </div>

                  <CardTitle className="text-2xl font-bold text-gray-900 mb-2">{tier.name}</CardTitle>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-baseline justify-center gap-2">
                      <span className="text-5xl font-bold text-gray-900">${tier.price}</span>
                      {tier.price > 0 && <span className="text-gray-500 text-lg">/{tier.period}</span>}
                    </div>
                    <p className="text-gray-600 leading-relaxed">{tier.description}</p>
                  </div>
                </CardHeader>

                <CardContent className="relative z-10 space-y-6">
                  <ul className="space-y-4">
                    {tier.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <div className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <Check className="h-3 w-3 text-green-600" />
                        </div>
                        <span className="text-gray-700 leading-relaxed">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button
                    className={`w-full py-4 text-lg font-semibold shadow-lg hover:shadow-xl transition-all duration-300 ${
                      tier.popular
                        ? `bg-gradient-to-r ${tier.gradient} hover:shadow-indigo-500/25 transform hover:scale-105`
                        : "bg-gray-900 hover:bg-gray-800"
                    }`}
                    size="lg"
                  >
                    {tier.price === 0 ? "Start Creating Free" : "Upgrade Now"}
                  </Button>

                  {tier.popular && (
                    <div className="text-center">
                      <Badge className="bg-green-100 text-green-700 border-green-200">
                        Save 40% vs monthly billing
                      </Badge>
                    </div>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16 space-y-6">
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-3xl p-8 text-white max-w-4xl mx-auto">
            <h3 className="text-3xl font-bold mb-4">Ready to Transform Your Creativity?</h3>
            <p className="text-xl text-indigo-100 mb-6">
              Join over 50,000 creators who have already started their journey to creative freedom.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button className="bg-white text-indigo-600 hover:bg-gray-100 px-8 py-3 text-lg font-semibold">
                Start Free Trial
              </Button>
              <Button variant="outline" className="border-white/30 text-white hover:bg-white/10 px-8 py-3 text-lg">
                Schedule Demo
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default MembershipTiers
