import React from 'react';
import { UploadManager } from '@/components/UploadManager';

const Upload: React.FC = () => {
  return <UploadManager />;
};

export default Upload;
