# Creator SaaS Backend Platform

A premium multi-tenant SaaS platform for creators with integrated content, payment, and analytics solutions.

## 🚀 Features

- **Premium UI Design**: Sephora meets Apple aesthetic with glass morphism and smooth animations
- **Multi-tenant Architecture**: Isolated data and customization per creator
- **Real-time Analytics**: Live dashboard with Supabase integration
- **File Upload System**: Drag-and-drop project integration
- **Product Marketplace**: Creator products with purchase tracking
- **Membership Tiers**: Flexible subscription management
- **Live Streaming**: Interactive streaming capabilities
- **Review System**: Customer feedback and ratings

## 🛠 Tech Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS
- **Backend**: Supabase (PostgreSQL, Auth, Storage)
- **UI Components**: Radix UI, Shadcn/ui
- **Build Tool**: Vite
- **Deployment**: Vercel

## 📦 Installation

\`\`\`bash
# Clone the repository
git clone <your-repo-url>
cd creator-saas-backend

# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
\`\`\`

## 🗄️ Database Setup

1. **Create Supabase Project**: Go to [supabase.com](https://supabase.com) and create a new project
2. **Run SQL Scripts**: Execute the scripts in the `scripts/` folder in order:
   - `01-create-tables.sql` - Creates all necessary tables
   - `02-seed-data.sql` - Adds demo data

3. **Update Environment**: Update `src/lib/supabase.ts` with your Supabase credentials

## 🚀 Deployment

### Vercel (Recommended)
1. Push your code to GitHub
2. Connect your repo to Vercel
3. Deploy automatically

### Manual Build
\`\`\`bash
npm run build
# Upload the `dist` folder to your hosting provider
\`\`\`

## 🔧 Configuration

### Supabase Setup
- Update `SUPABASE_URL` and `SUPABASE_ANON_KEY` in `src/lib/supabase.ts`
- Enable Row Level Security (RLS) on all tables
- Configure storage buckets for file uploads

### Environment Variables
\`\`\`env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
\`\`\`

## 📊 Database Schema

- **tenants**: Creator organizations
- **products**: Marketplace items
- **members**: User memberships
- **uploads**: File management
- **analytics**: Event tracking

## 🎨 Design System

- **Colors**: Purple/Blue gradients with premium accents
- **Typography**: Inter font family
- **Components**: Glass morphism with subtle shadows
- **Animations**: Smooth transitions and hover effects

## 🔐 Security

- Row Level Security (RLS) enabled
- User authentication via Supabase Auth
- Secure file uploads with validation
- API rate limiting

## 📈 Analytics

- Real-time event tracking
- Revenue and growth metrics
- User engagement analytics
- Custom dashboard widgets

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📄 License

MIT License - see LICENSE file for details

## 🆘 Support

For support, email support@creatoruniverse.com or join our Discord community.
