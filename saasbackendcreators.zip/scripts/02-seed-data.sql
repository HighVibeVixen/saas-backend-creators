-- Insert demo tenant
INSERT INTO tenants (id, name, slug, description, plan, status) VALUES 
('550e8400-e29b-41d4-a716-446655440000', 'Creator Universe Demo', 'creator-universe', 'A premium creator platform for digital entrepreneurs', 'pro', 'active')
ON CONFLICT (slug) DO NOTHING;

-- Insert demo products
INSERT INTO products (tenant_id, title, description, price, original_price, featured, image_url, category) VALUES 
(
    '550e8400-e29b-41d4-a716-446655440000',
    'Premium Design Mastery Course',
    'Master the art of modern design with this comprehensive course covering UI/UX principles, color theory, and advanced techniques used by top designers.',
    299.00,
    399.00,
    true,
    '/placeholder.svg?height=300&width=400&text=Design+Course',
    'course'
),
(
    '550e8400-e29b-41d4-a716-446655440000',
    'Creative Workshop Bundle',
    'Access to 12 exclusive workshops covering photography, design, content creation, and brand building strategies.',
    199.00,
    299.00,
    false,
    '/placeholder.svg?height=300&width=400&text=Workshop+Bundle',
    'workshop'
),
(
    '550e8400-e29b-41d4-a716-446655440000',
    'Brand Identity Masterclass',
    'Learn to create compelling brand identities that resonate with your target audience and drive business growth.',
    149.00,
    null,
    false,
    '/placeholder.svg?height=300&width=400&text=Brand+Masterclass',
    'course'
),
(
    '550e8400-e29b-41d4-a716-446655440000',
    'Digital Marketing Toolkit',
    'Complete toolkit with templates, guides, and resources for successful digital marketing campaigns.',
    99.00,
    149.00,
    true,
    '/placeholder.svg?height=300&width=400&text=Marketing+Toolkit',
    'template'
),
(
    '550e8400-e29b-41d4-a716-446655440000',
    'Content Creator Starter Pack',
    'Everything you need to start your content creation journey, including templates, presets, and step-by-step guides.',
    79.00,
    null,
    false,
    '/placeholder.svg?height=300&width=400&text=Starter+Pack',
    'bundle'
),
(
    '550e8400-e29b-41d4-a716-446655440000',
    'Advanced Photography Course',
    'Professional photography techniques, lighting setups, and post-processing workflows for stunning results.',
    249.00,
    349.00,
    false,
    '/placeholder.svg?height=300&width=400&text=Photography+Course',
    'course'
)
ON CONFLICT DO NOTHING;

-- Insert demo analytics data
INSERT INTO analytics (tenant_id, event_type, event_data) VALUES 
(
    '550e8400-e29b-41d4-a716-446655440000',
    'revenue',
    '{"amount": 8245, "month": "2024-01", "currency": "USD"}'
),
(
    '550e8400-e29b-41d4-a716-446655440000',
    'members',
    '{"count": 1234, "month": "2024-01", "new_members": 89}'
),
(
    '550e8400-e29b-41d4-a716-446655440000',
    'page_views',
    '{"count": 12400, "month": "2024-01", "unique_visitors": 8900}'
)
ON CONFLICT DO NOTHING;
